"""Constants for the digitalstrom integration."""

DOMAIN = "digitalstrom_dss"
